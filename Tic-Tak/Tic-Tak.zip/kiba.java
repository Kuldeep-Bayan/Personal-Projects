import java.util.PriorityQueue;

class kiba{
    public static int solve(int a[], int n)
    {
        int sum1 = 0, dif = 0;
 
        PriorityQueue<Integer> pq = new PriorityQueue<>();
        for (int i = 0; i < n; i++)
        {
            if (!pq.isEmpty() && pq.element() < a[i])
            {
                dif = a[i] - pq.element();
                sum1 += dif;
                pq.remove();
                  pq.add(a[i]);
            }
            pq.add(a[i]);
        }

        int sum2 = 0;
        dif = 0;
 
        PriorityQueue<Integer> pq = new PriorityQueue<>();
        for (int i = n-1; i >=0; i--)
        {
            if (!pq.isEmpty() && pq.element() < a[i])
            {
                dif = a[i] - pq.element();
                sum2 += dif;
                pq.remove();
                  pq.add(a[i]);
            }
            pq.add(a[i]);
        }
        return Math.min(sum1,sum2);
    }
    public static void main(String[] args) {
        int arr[]={2000,2,3,6,10};
        System.out.println(solve(arr,5));
    }
}